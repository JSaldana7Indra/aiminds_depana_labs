export default function Page() {
    return <p>Customer page</p>    
}