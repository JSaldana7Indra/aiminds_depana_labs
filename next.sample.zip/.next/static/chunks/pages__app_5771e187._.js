(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__aec0a1fa._.js",
  "static/chunks/a14e7_react-dom_638ad3bb._.js",
  "static/chunks/node_modules__pnpm_51c25b77._.js",
  "static/chunks/[root-of-the-server]__49fd8634._.js"
],
    source: "entry"
});
